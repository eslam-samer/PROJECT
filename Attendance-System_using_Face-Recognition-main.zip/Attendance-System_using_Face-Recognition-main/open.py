import subprocess
def open_face():
    subprocess.call(["python", "Attendence\main.py"])

open_face()